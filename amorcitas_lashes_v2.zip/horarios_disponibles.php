<?php
include 'conexion.php';
$fecha = $_GET['fecha'];
$horarios = [
  '10:00', '11:00', '12:00', '13:00', '14:00',
  '15:00', '16:00', '17:00', '18:00'
];
$result = $conn->query("SELECT hora FROM turnos WHERE fecha = '$fecha'");
$ocupados = [];
while ($row = $result->fetch_assoc()) {
  $ocupados[] = $row['hora'];
}
$disponibles = array_diff($horarios, $ocupados);
echo json_encode(array_values($disponibles));
?>
